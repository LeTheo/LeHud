var app = new Vue({
    el: "#app",
    data: {
        show: true,
        thirst: 20,
        hunger: 30,
        armor: 50,
        oxy: 80,
        health: 100,
        street1: '',
        street2: '',
        showSpeedo: true,
        carSpeed:100,
        seatbelt: false,
        doors: true,
        lights: false,
        engine: false,
        showStamina: false,
        fuelLevel:60,
    }
})

window.addEventListener("message", (event) => {
    switch (event.data.action) {
        case "carHUD":
            app.showSpeedo = event.data.value
            break;
        case "carData":
            app.carSpeed = event.data.carSpeed
            app.seatbelt = event.data.seatbelt
            app.doors = event.data.doors
            app.lights = event.data.lights
            app.engine = event.data.engine
            app.fuelLevel = event.data.fuel
            break;
        case "setHunger":
            app.hunger = event.data.hunger
            break;
        case "setThirst":
            app.thirst = event.data.thirst
            break;
        case "setStatus":
            app.health = event.data.health
            app.armor = event.data.armor
            break;
        case "setStreet":
            app.street1 = event.data.strt1
            app.street2 = event.data.strt2
            break;
        case "staminaShow":
            app.showStamina = event.data.value
            break;
        case "setstamina":
            app.oxy = event.data.value
            break;
        case "show":
            app.show = event.data.value
            break;

        default:
            console.log("unknow");
            break;
    }
})