fx_version 'adamant'

game 'gta5'

author 'MiLaD#6713'
description 'MJ HUD'
version '1.0'

ui_page 'html/index.html'

files {
	'html/**',
}


client_scripts {
	'client.lua',
}
